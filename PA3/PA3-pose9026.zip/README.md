Pourna Sengupta 
Programming Assignment 3

multilookup.h: Header file for program 
multilookup.c: Multi-threaded application program to resolve domain names to IP addresses 
Makefile: Includes clean and submit commands
performance.txt: Text output of requester and resolver threads and serviced files. 